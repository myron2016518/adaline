export const __manage_token__ = state => state.__manage_token__

export const __manage_userinfo__ = state => state.__manage_userinfo__

export const __manage_account__ = state => state.__manage_account__

export const __manage_userid__ = state => state.__manage_userid__

export const __manage_auth__ = state => state.__manage_auth__

export const __menu_key__ = state => state.__menu_key__
