export const __current_frames__ = state => state.__current_frames__

export const __not_work__ = state => state.__not_work__

export const __play_state__ = state => state.__play_state__
