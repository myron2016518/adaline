const state = {
    __current_frames__: -1,                                    // 当前帧
    __not_work__: '',                                          // 用于未做的业务组件，例如显示：T100U9101
    __play_state__: false,                                     // 播放状态：true播放中、false未播放
}

export default state
