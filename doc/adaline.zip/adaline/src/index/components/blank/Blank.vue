<template>
    <div class="tu-wrapper">
        <div class="center-block">
        </div>
    </div>
</template>

<script>
    export default {
        name: "Blank"
    }
</script>

<style scoped lang="scss">
    .tu-wrapper {
        padding: 12px 0;
    }

    .center-block {
        position: relative;
        margin: 0 auto;
        width: 100%;
        height: 100%;
        max-width: 1024px;
    }
</style>
