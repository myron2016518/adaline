<template>
    <div style="display: inline-block; width: 0; height: 0"></div>
</template>

<script>
    export default {
        name: "Ignore"
    }
</script>

<style scoped>

</style>
