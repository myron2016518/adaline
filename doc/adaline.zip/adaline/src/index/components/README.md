# play页面组件说明

+ blank->Blank：空白组件，用于占位
+ empty->Empty：当某个业务组件还没有做时，显示的提示组件
+ start->Start：第一此进入页面时，页面上显示一个播放图标

# manage 文件夹存放“采集审核”平台的组件
