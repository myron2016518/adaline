/** Nginx做反向代理的前缀识别 **/
export const PROXY_PREFIX = '/proxy_adaline'
/** Nginx做反向代理的前缀识别（用户中心） **/
export const PROXY_PREFIX_CENTER = '/proxy_user_center'
